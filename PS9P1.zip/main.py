def DiscountPrice(price):
    DiscountPrice=0.0
    DiscountAmt= qty * price * DiscountRate
    return DiscountPrice,DiscountAmt

DiscountRate=input("Enter Discount Rate :")
price=int(input("Enter price:"))
qty=int(input("Enter quantity:"))

DiscountPrice, DiscountAmt=DiscountPrice(price)

print("Quantity:",qty)
print("Discount Rate:",DiscountRate)
print("Discount Price:",DiscountPrice)
print("Discount Amount:",DiscountAmt)
