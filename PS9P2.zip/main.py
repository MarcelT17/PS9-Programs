def average(score):
    score=0.0
    total=Score1 + Score2 + Score3
    return average, total
  
Score1=input("Enter score  :")
Score2=input("Enter score  :")
Score3=input("Enter score  :")
lastname=input("Enter your last name :")

average, total=average(score)

print("Person Name:",lastname)
print("Average:",average)
print("Total:",total)
print("Score:", score)