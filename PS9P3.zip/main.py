def Comission(sales):
    comission=0.0
    if sales<=100000:
        comission=sales*0.05
    else:
        comission=sales*0.10
    nextyeartarget=sales*0.05
    return comission,nextyeartarget

lastname=input("Enter your last name :")
sales=int(input("Enter sales:"))
comission, nextyeartarget=Comission(sales)
print("Sales Person Name:",lastname)
print("Commision:",comission)
print("Next year target:",nextyeartarget)
