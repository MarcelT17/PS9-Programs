def total(unitprice):
    total=0.0
    Tax= 0.07
    return total, Tax

Total = unitprice * qty * Tax

qty=input("Enter quantity :")
unitprice=int(input("Enter the unitprice  :"))

Total, Tax=Total(unitprice)

print("Quantity:",qty)
print("Unit Price:",unitprice)
print("Total:",total)
print("tax:", Tax)