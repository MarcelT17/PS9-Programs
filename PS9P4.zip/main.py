def Avg(Score):
    Avg=0.0
    game1 = input("Score for game 1: ")
    game2 = input("Score for game 2: ")
    game3 = input("Score for game 3: ")
    AvgH= Avg * handicap
    return Avg,AvgH

Avg= (game1 + game2 +game3) / 3

lastname=input("Enter your last name :")
handicap=int(input("Enter the handicap  :"))

Avg, AvgH=Average(Score)

print("Person Name:",lastname)
print("Average:",Avg)
print("Average with Handicap:",AvgH)
print("Handicap:", handicap)